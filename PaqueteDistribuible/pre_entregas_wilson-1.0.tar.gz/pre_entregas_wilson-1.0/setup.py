from setuptools import setup
 
setup(
    name= "PRE-ENTREGAS-Wilson",
    version="1.0",
    description="Es la segunda pre-entrega",
    author="Macarena Wilson",
    author_email="macus_wilson@hotmail.com",
    
    packages=["PRE-ENTREGAS"]
)